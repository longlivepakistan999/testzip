<?php
    
    error_reporting(E_ALL);
    ini_set('display_errors', True);
    
    include '../index.php';
    
?>